import rclpy
import math
from rclpy.node import Node
from std_msgs.msg import Float32

class Signal_Generator(Node):
    def __init__(self):
        super().__init__('signal_generator_node')
        self.signal_pub = self.create_publisher(Float32, "signal",10)
        self.time_pub = self.create_publisher(Float32, "time", 10)
        self.timer_period=0.1
        self.timev=0
        self.msgsignal = Float32()
        self.msgtime = Float32()
        self.timer = self.create_timer(self.timer_period, self.timer_callback)
        self.get_logger().info('Signal Generator Node Succesfully Initialized!!')

    def timer_callback(self):
        self.timev=self.timev+self.timer_period
        self.msgsignal.data = math.sin(self.timev)
        self.msgtime.data=self.timev
        self.signal_pub.publish(self.msgsignal)
        self.time_pub.publish(self.msgtime)

def main(args=None):
    rclpy.init(args=args)
    m_p = Signal_Generator()
    rclpy.spin(m_p)

    #LIberar memoria del sistema
    m_p.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()
