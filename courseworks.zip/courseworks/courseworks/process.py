import rclpy
import math
from rclpy.node import Node
from std_msgs.msg import Float32


class Signal_Process(Node):
    def __init__(self):
        super().__init__('process_node') #Iniciamos el nodo de procesamiento
        self.subsignal = self.create_subscription(Float32, "signal", self.signal_callback, 10)  # Subscripción a sennal
        self.subtime = self.create_subscription(Float32, "time", self.time_callback, 10)  # Subscripción al tiempo
        self.signal_proc = self.create_publisher(Float32, 'proc_signal', 10)  # Publisher sennal procesada
        self.alpha = 2  # Valor alpha
        self.msg = Float32() #Al publish un mensaje
        self.msgt = Float32()

    def signal_callback(self, msgsignal):
        self.procsignal = Float32()
        self.procsignal = msgsignal.data
        
        #offset
        self.procsignal = self.procsignal + self.alpha #Realizamos el offset en la sennal
        self.procsignal = max(0, self.procsignal)  #Aseguramos que quede unicamente en la parte positiva
        #Amplitud
        self.procsignal = self.procsignal / 2.0 #Amplitud de la sennal a la mitad
        #Cambio de Fase
        #???
        self.msg.data = self.procsignal
        self.signal_proc.publish(self.msg) #EL publisher envia lo procesado
        self.get_logger().info('Signal: {}'.format(self.msg)) #Revision visual de los procesado
        self.get_logger().info('Signal Process Node Succesfully Initialized!!')


    def time_callback(self, msgtime):
        self.msgt=msgtime.data
        self.get_logger().info('Time: {}'.format(self.msgt)) #Revision del tiempo


def main(args=None):
    rclpy.init(args=args)
    m_s = Signal_Process()
    rclpy.spin(m_s)

    m_s.destroy_node()
    rclpy.shutdown()


if __name__ == '__main__':
    main()
