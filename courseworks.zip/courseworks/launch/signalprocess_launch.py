import os
from launch import LaunchDescription #Que es lo que queremos que lance. Cada que tengamos uno nuevo copiar y pegar por cada cosa que necesitamos
from launch_ros.actions import Node #Este sirve para cargar un nodo

def generate_launch_description():
    signalgenerator_node = Node(package='courseworks', executable='signal_generator',output='screen') #EL paquete debe estar escrito exactamente igual a como se lama el paquete, igual el ejecutable

    signalprocess_node = Node(package='courseworks', executable='process',output='screen') #De donde viene, que ejecutar, por donde
    
    rqt_graph_node = Node(package='rqt_graph', executable='rqt_graph',output='screen')

    rqt_plot_node = Node(package='rqt_plot', executable='rqt_plot',output='screen')

    l_d = LaunchDescription([signalgenerator_node,signalprocess_node,rqt_graph_node, rqt_plot_node])
    return l_d